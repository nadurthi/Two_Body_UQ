/*
 * $Id$
 */

package com.ng.mdeac.common.celestial;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;
import com.ng.mdeac.common.coordinates.GeographicLocation;
import com.ng.mdeac.common.earth.EarthGeometry;
import com.ng.mdeac.common.earth.WGS84Geometry;
import com.ng.mdeac.common.time.JulianDate;
import com.ng.mdeac.common.time.RealTime;

/**
 *
 * @author Darren Hiebert
 */
public class MoonSimpleTest {

	private static final TimeZone gmt = TimeZone.getTimeZone("GMT");
	private static final DateFormat df = new SimpleDateFormat("d MMM yyyy HH:mm:ss.S z");

	public static void main(String[] args) {
		df.setTimeZone(gmt);
		final EarthGeometry earth = new WGS84Geometry();
		example53();
		example54(earth);
		example54b(earth);
		antarctic1(earth);
		arctic1(earth);
		arctic2(earth);
	}

	// Example 5-3 from Vallado, p. 276
	private static void example53() {
		Calendar cal = new GregorianCalendar(1994, Calendar.APRIL, 28, 0, 0, 0);
		cal.setTimeZone(gmt);
		Moon moon = new Moon(cal);
		System.out.printf("Date: %s\n", df.format(cal.getTime()));
		System.out.println(moon);
	}

	// Example 5-4 from Vallado, pp. 280-282
	private static void example54(EarthGeometry earth) {
		JulianDate rsDate = new JulianDate(1998, 8, 21, 0, 0, 0);
		GeographicLocation site = new GeographicLocation(earth, new RealTime(rsDate), 40.0, 0.0, 0.0, GeographicLocation.DEGREES);
		final JulianDate rise = Moon.riseTime(rsDate, site);
		final JulianDate set = Moon.setTime(rsDate, site);
		System.out.println("At " + site + ", Moon rises at " + df.format(rise.date()) + " and sets at " + df.format(set.date()));
	}

	// Example http://www.skyandtelescope.com/observing/almanac/almanacCustom
	// which gives rise: 18:33 UT, set: 04:30 UT
	private static void example54b(EarthGeometry earth) {
		JulianDate rsDate = new JulianDate(1998, 8, 21, 0, 0, 0);
		GeographicLocation site = new GeographicLocation(earth, new RealTime(rsDate), -40.0, -179.9833, 0.0, GeographicLocation.DEGREES);
		final JulianDate rise = Moon.riseTime(rsDate, site);
		final JulianDate set = Moon.setTime(rsDate, site);
		System.out.println("At " + site + ", Moon rises at " + df.format(rise.date()) + " and sets at " + df.format(set.date()));
	}

	// Example http://www.skyandtelescope.com/observing/almanac/almanacCustom
	// which gives rise: 00:58 UT (7/22), set: 08:58 UT
	private static void antarctic1(EarthGeometry earth) {
		JulianDate rsDate = new JulianDate(2011, 7, 21, 0, 0, 0);
		GeographicLocation site = new GeographicLocation(earth, new RealTime(rsDate), -70.0, 0.0, 0.0, GeographicLocation.DEGREES);
		final JulianDate rise = Moon.riseTime(rsDate, site);
		final JulianDate set = Moon.setTime(rsDate, site);
		System.out.println("At " + site + ", Moon rises at " + df.format(rise.date()) + " and sets at " + df.format(set.date()));
	}

	// Example http://www.skyandtelescope.com/observing/almanac/almanacCustom
	// which gives rise: 19:31 UT (9/11), set: 19:21 (08/29) UT
	private static void arctic1(EarthGeometry earth) {
		JulianDate rsDate = new JulianDate(2011, 8, 21, 0, 0, 0);
		GeographicLocation site = new GeographicLocation(earth, new RealTime(rsDate), 85.0, 0.0, 0.0, GeographicLocation.DEGREES);
		final JulianDate rise = Moon.riseTime(rsDate, site);
		final JulianDate set = Moon.setTime(rsDate, site);
		System.out.println("At " + site + ", Moon rises at " + df.format(rise.date()) + " and sets at " + df.format(set.date()));
	}

	// Example http://www.skyandtelescope.com/observing/almanac/almanacCustom
	// which gives rise: 23:52 UT (7/18), set: 07:27 (7/19) UT
	private static void arctic2(EarthGeometry earth) {
		JulianDate rsDate = new JulianDate(2011, 7, 8, 0, 0, 0);
		GeographicLocation site = new GeographicLocation(earth, new RealTime(rsDate), 85.0, 0.0, 0.0, GeographicLocation.DEGREES);
		final JulianDate rise = Moon.riseTime(rsDate, site);
		final JulianDate set = Moon.setTime(rsDate, site);
		System.out.println("At " + site + ", Moon rises at " + df.format(rise.date()) + " and sets at " + df.format(set.date()));
	}

}
