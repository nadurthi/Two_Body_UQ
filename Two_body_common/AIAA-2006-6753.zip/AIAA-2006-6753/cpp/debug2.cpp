     if (help == 'y')
       //    if (dbgfile != NULL)
       {
       printf( "%84s\n",
              " ------------------ after dscom :-----------------");
       printf( "    inputs :\n");
       printf(
          "%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f\n",
          "epoch", epoch, "ep", ep, "argpp", argpp, "tc", tc,
          "inclp", inclp, "nodep", nodep);
       printf( "%7s%15.9f\n", "np", np);
       printf( "    outputs :\n");
       printf(
          "%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f\n",
          "snodm", snodm, "cnodm", cnodm, "sinim", sinim, "cosim", cosim,
          "sinomm", sinomm, "cosomm", cosomm);
       printf(
          "%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f\n",
          "day", day, "e3", e3, "ee2", ee2, "em", em,
          "emsq", emsq, "gam", gam);
       printf(
          "%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f\n",
          "peo", peo, "pgho", pgho, "pho", pho, "pinco", pinco,
          "plo", plo);
       printf(
          "%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f\n",
          "rtemsq", rtemsq, "se2", se2, "se3", se3, "sgh2", sgh2,
          "sgh3", sgh3, "sgh4", sgh4);
       printf(
          "%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f\n",
          "sh2", sh2, "sh3", sh3, "si2", si2, "si3", si3,
          "sl2", sl2, "sl3", sl3);
       printf(
          "%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f\n",
          "sl4", sl4, "s1", s1, "s2", s2, "s3", s3,
          "s4", s4, "s5", s5);
       printf(
          "%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f\n",
          "s6", s6, "s7", s7, "ss1", ss1, "ss2", ss2,
          "ss3", ss3, "ss4", ss4);
       printf(
          "%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f\n",
          "ss5", ss5, "ss6", ss6, "ss7", ss7, "sz1", sz1,
          "sz2", sz2, "sz3", sz3);
       printf(
          "%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f\n",
          "sz11", sz11, "sz12", sz12, "sz13", sz13, "sz21", sz21,
          "sz22", sz22, "sz23", sz23);
       printf(
          "%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f\n",
          "sz31", sz31, "sz32", sz32, "sz33", sz33, "xgh2", xgh2,
          "xgh3", xgh3, "xgh4", xgh4);
       printf(
          "%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f\n",
          "xh2", xh2, "xh3", xh3, "xi2", xi2, "xi3", xi3,
          "xl2", xl2, "xl3", xl3);
       printf(
          "%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f\n",
          "xl4", xl4, "nm", nm, "z1", z1, "z2", z2,
          "z3", z3, "z11", z11);
       printf(
          "%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f\n",
          "z12", z12, "z13", z13, "z21", z21, "z22", z22,
          "z23", z23, "z31", z31);
       printf(
          "%7s%15.9f%7s%15.9f%7s%15.9f%7s%15.9f\n",
          "z32", z32, "z33", z33, "zmol", zmol, "zmos", zmos);
      }

